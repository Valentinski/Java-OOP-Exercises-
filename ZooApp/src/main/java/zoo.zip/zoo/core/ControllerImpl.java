package zoo.core;

public class ControllerImpl implements Controller {

    @Override
    public String addArea(String areaType, String areaName) {
        return null;
    }

    @Override
    public String buyFood(String foodType) {
        return null;
    }

    @Override
    public String foodForArea(String areaName, String foodType) {
        return null;
    }

    @Override
    public String addAnimal(String areaName, String animalType, String animalName, String kind, double price) {
        return null;
    }

    @Override
    public String feedAnimal(String areaName) {
        return null;
    }

    @Override
    public String calculateKg(String areaName) {
        return null;
    }

    @Override
    public String getStatistics() {
        return null;
    }
}
